<?php
    $con = mysqli_connect("fdb1029.awardspace.net", "4530883_rbm", "archdevs4", "4530883_rbm") or die("Couldn't connect");
?>
